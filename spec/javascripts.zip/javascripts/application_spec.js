require("spec_helper.js");
require("../../public/javascripts/json2.js");
require("../../public/coffeescripts/application.js");

Screw.Unit(function(){
  
  describe("Medication Form", function(){
    it("should set medication form height correctly", function(){
      var $ht = 0;
      var $newht = $ht + 600;  
      $('#main_inner').height($newht);
      expect($('#main_inner').height()).to(equal, 600);
    });
    
    it("should write patient data to JSON string", function(){
      $('#patient_relation_first_name').val("Joe"),
      $('#patient_relation_last_name').val("Relation"),
      $('#patient_relation_middle_initial').val("R"),
      $('#patient_relation_phone').val("808-808-8080"),
      $('#patient_relation_cell_phone').val("808-808-8088"),
      $('#patient_relation_email').val("joerelation@email.com"),
      $('#patient_first_name').val('Test');
      $('#patient_last_name').val('Patient');
      $('#patient_middle_initial').val("P"),
      $('#patient_address').val("303 Some Street"),
      $('#patient_address2').val("Suite 1"),
      $('#patient_city').val("Charleston"),
      $('#patient_state').val("SC"),
      $('#patient_zip').val("29464"),
      $('#patient_dob').val("07/07/1975"),
      $('#patient_email').val("patient@email.com"),
      $('#patient_phone').val("803-803-8030"),
      data = {};
      data.patient = {};
      arr = {
        relation_first_name: $('#patient_relation_first_name').val(),
        relation_last_name: $('#patient_relation_last_name').val(),
        relation_middle_initial: $('#patient_relation_middle_initial').val(),
        relation_phone: $('#patient_relation_phone').val(),
        relation_cell_phone: $('#patient_relation_cell_phone').val(),
        relation_email: $('#patient_relation_email').val(),
        first_name: $('#patient_first_name').val(),
        last_name: $('#patient_last_name').val(),
        middle_initial: $('#patient_middle_initial').val(),
        address: $('#patient_address').val(),
        address2: $('#patient_address2').val(),
        city: $('#patient_city').val(),
        state: $('#patient_state').val(),
        zip: $('#patient_zip').val(),
        dob: $('#patient_dob').val(),
        email: $('#patient_email').val(),
        phone: $('#patient_phone').val(),
      }
      data.patient = arr;
      patient = JSON.stringify(data);
      expect(patient).to(equal, '{\"patient\":{\"relation_first_name\":\"Joe\",\"relation_last_name\":\"Relation\",\"relation_middle_initial\":\"R\",\"relation_phone\":\"808-808-8080\",\"relation_cell_phone\":\"808-808-8088\",\"relation_email\":\"joerelation@email.com\",\"first_name\":\"Test\",\"last_name\":\"Patient\",\"middle_initial\":\"P\",\"address\":\"303 Some Street\",\"address2\":\"Suite 1\",\"city\":\"Charleston\",\"state\":\"SC\",\"zip\":\"29464\",\"dob\":\"07/07/1975\",\"email\":\"patient@email.com\",\"phone\":\"803-803-8030\"}}')
    });
    
    it("should write patient_cardiologist to JSON string", function(){
      $('select#patient_cardiologist').val("Dr. Cardiologist")
      data = {};
      data.patient = {};
      arr = {
        cardiologist: $('select#patient_cardiologist').val()
      }
      data.patient = arr;
      patient = JSON.stringify(data);
      expect(patient).to(equal, '{\"patient\":{\"cardiologist\":\"Dr. Cardiologist\"}}')
    });
  
    it("should write patient_gender to JSON string", function(){
      $("input[name='patient[gender]']:checked").val("Male"),
      data = {};
      data.patient = {};
      arr = {
        gender: $("input[name='patient[gender]']").val()
      }
      data.patient = arr;
      patient = JSON.stringify(data);
      expect(patient).to(equal, '{\"patient\":{\"gender\":\"Male\"}}')
    });
    
  });
});



