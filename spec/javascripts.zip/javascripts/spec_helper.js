Screw.Unit(function() {
  before(function() {
    $('#medications_fields_template').html('');
  });
});
